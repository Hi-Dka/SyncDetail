# qBittorrent WebUI Configuration
QB_ENABLED = True
QB_URL = "http://localhost:6500"
QB_USER = "hidka"
QB_PASS = "YanGxinXINx98Z5~"

# qBittorrent Processing Settings
QB_SIMILARITY_THRESHOLD = 90
QB_EXCLUDE_CATEGORIES = ["刷流"]  # Categories to exclude from processing

# File System Paths
MEDIA_PATH = "~/Media/plex"    # 要监听的媒体文件路径
SOURCE_PATH = "~/Media/source"  # 源文件路径
DB_PATH = "~/Media/file_links.db"  # SQLite 数据库存储位置
